﻿///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Adryan Knight - SNHU Student / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// IMPORTANT: start with zero textures loaded
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glDeleteTextures(1, &m_textureIDs[i].ID);
		m_textureIDs[i].ID = 0;
	}
	m_loadedTextures = 0;
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// Meshes used in the scene
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();

	// If your template supports these, they help the headphones look right.
	// If you get a compile error on these two lines, comment them out and we can do headphones with cylinders/boxes.
	m_basicMeshes->LoadTorusMesh();
	m_basicMeshes->LoadSphereMesh();

	// Textures (must exist in Source/Textures relative to your working directory)
	CreateGLTexture("Source/Textures/wood.jpg", "wood");    // desk
	CreateGLTexture("Source/Textures/metal.jpg", "metalTex");// tower/stand/frame
	CreateGLTexture("Source/Textures/stone.jpg", "wall");    // wall/background
	CreateGLTexture("Source/Textures/black.jpg", "black");   // keyboard/mouse/headphones
	CreateGLTexture("Source/Textures/screen.jpg", "screen");  // monitor wallpaper + picture content

	BindGLTextures();

	DefineObjectMaterials();
	SetupSceneLights();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;

	// ---------------------------
	// WALL (behind the desk)
	// ---------------------------
	scaleXYZ = glm::vec3(18.0f, 1.0f, 10.0f);
	positionXYZ = glm::vec3(0.0f, 5.0f, -5.5f);

	SetTransformations(scaleXYZ, -90.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(1, 1, 1, 1);
	SetShaderMaterial("default");
	SetShaderTexture("wall");
	SetTextureUVScale(2.0f, 2.0f);
	m_basicMeshes->DrawPlaneMesh();

	// ---------------------------
	// DESK TOP (thinner, slightly higher)
	// ---------------------------
	scaleXYZ = glm::vec3(14.0f, 0.35f, 6.0f);
	positionXYZ = glm::vec3(0.0f, 1.35f, 0.0f);

	SetTransformations(scaleXYZ, 0, 0, 0, positionXYZ);
	SetShaderMaterial("default");
	SetShaderTexture("wood");
	SetTextureUVScale(2.5f, 2.0f);
	m_basicMeshes->DrawBoxMesh();

	// ---------------------------
	// MONITOR (bigger, centered)
	// ---------------------------
	// Monitor body
	scaleXYZ = glm::vec3(7.6f, 3.8f, 0.35f);
	positionXYZ = glm::vec3(0.0f, 4.75f, -1.35f);

	SetTransformations(scaleXYZ, 0, 0, 0, positionXYZ);
	SetShaderMaterial("metal");
	SetShaderTexture("metalTex");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

// ---------------------------
// MONITOR STAND (skinnier + centered)
// ---------------------------
	float monitorCenterX = 0.0f;   // keep monitor centered
	float standCenterZ = -1.30f; // slightly forward so it reads clean

	// Stand post (SKINNY)
	scaleXYZ = glm::vec3(0.70f, 1.10f, 0.45f);                 // skinnier than before
	positionXYZ = glm::vec3(monitorCenterX, 2.25f, standCenterZ);

	SetTransformations(scaleXYZ, 0, 0, 0, positionXYZ);
	SetShaderMaterial("metal");
	SetShaderTexture("metalTex");
	m_basicMeshes->DrawBoxMesh();

	// Stand base (wider)
	scaleXYZ = glm::vec3(2.40f, 0.14f, 1.35f);
	positionXYZ = glm::vec3(monitorCenterX, 1.52f, -0.95f);    // base stays centered on monitor

	SetTransformations(scaleXYZ, 0, 0, 0, positionXYZ);
	SetShaderMaterial("metal");
	SetShaderTexture("metalTex");
	m_basicMeshes->DrawBoxMesh();

	// ---------------------------
	// PC TOWER (right side)
	// ---------------------------
	glm::vec3 towerScale = glm::vec3(2.4f, 4.7f, 2.1f);
	glm::vec3 towerPos = glm::vec3(5.75f, 3.15f, -0.65f);

	SetTransformations(towerScale, 0, 0, 0, towerPos);
	SetShaderMaterial("metal");
	SetShaderTexture("metalTex");
	m_basicMeshes->DrawBoxMesh();

	// ---------------------------
	// PC TOWER FANS (robust: centered + raised + unclipped)
	// ---------------------------

	// Front face Z = centerZ + half depth
	float towerFrontZ = towerPos.z + (towerScale.z * 0.5f);

	// Slight offset forward to avoid clipping into the tower
	float fanZ = towerFrontZ + 0.05f;

	// Center fans on tower X
	float fanCenterX = towerPos.x;

	// Fan sizing (3 full circles)
	float outerR = 0.65f;
	float innerR = 0.30f;

	// Vertical layout: tight spacing + raised stack
	float spacing = 1.25f;
	float midY = towerPos.y + 0.35f;   // raise entire stack
	float topY = midY + spacing;
	float botY = midY - spacing;

	float fanYs[3] = { topY, midY, botY };

	for (int i = 0; i < 3; i++)
	{
		float y = fanYs[i];

		// Outer ring
		glm::vec3 fanScaleOuter = glm::vec3(outerR, 0.045f, outerR);
		glm::vec3 fanPosOuter = glm::vec3(fanCenterX, y, fanZ);

		SetTransformations(fanScaleOuter, 90.0f, 0.0f, 0.0f, fanPosOuter);
		SetShaderMaterial("default");
		SetShaderColor(1.0f, 0.55f, 0.10f, 1.0f);
		m_basicMeshes->DrawCylinderMesh();

		// Inner hub
		glm::vec3 fanScaleInner = glm::vec3(innerR, 0.050f, innerR);
		glm::vec3 fanPosInner = glm::vec3(fanCenterX, y, fanZ + 0.01f);

		SetTransformations(fanScaleInner, 90.0f, 0.0f, 0.0f, fanPosInner);
		SetShaderColor(0.12f, 0.06f, 0.04f, 1.0f);
		m_basicMeshes->DrawCylinderMesh();
	}

	// Reset color
	SetShaderColor(1, 1, 1, 1);

	// ---------------------------
	// KEYBOARD (center front)
	// ---------------------------
	scaleXYZ = glm::vec3(5.2f, 0.18f, 1.45f);
	positionXYZ = glm::vec3(0.0f, 1.55f, 0.75f);

	SetTransformations(scaleXYZ, 0, 0, 0, positionXYZ);
	SetShaderMaterial("matteBlack");
	SetShaderTexture("black");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// ---------------------------
	// MOUSE (right)
	// ---------------------------
	// Mouse
	scaleXYZ = glm::vec3(0.55f, 0.22f, 0.85f);
	positionXYZ = glm::vec3(3.2f, 1.62f, 0.85f);

	SetTransformations(scaleXYZ, 0, 0, 0, positionXYZ);
	SetShaderMaterial("matteBlack");
	SetShaderTexture("black");
	m_basicMeshes->DrawBoxMesh();

	// ---------------------------
	// COFFEE MUG (left front)
	// ---------------------------
	scaleXYZ = glm::vec3(0.38f, 0.58f, 0.38f);
	positionXYZ = glm::vec3(-3.15f, 1.65f, 0.75f);

	SetTransformations(scaleXYZ, 0, 0, 0, positionXYZ);
	SetShaderMaterial("matteBlack");
	SetShaderTexture("black");
	m_basicMeshes->DrawCylinderMesh();

	// ---------------------------
	// WALL FRAME (top-left)
	// ---------------------------
	// outer frame
	scaleXYZ = glm::vec3(2.2f, 2.6f, 0.18f);
	positionXYZ = glm::vec3(-6.0f, 6.25f, -5.25f);

	SetTransformations(scaleXYZ, 0, 0, 0, positionXYZ);
	SetShaderMaterial("metal");
	SetShaderTexture("metalTex");
	m_basicMeshes->DrawBoxMesh();

	// inner picture (thin)
	scaleXYZ = glm::vec3(1.9f, 2.3f, 0.05f);
	positionXYZ = glm::vec3(-6.0f, 6.25f, -5.08f);

	SetTransformations(scaleXYZ, 0, 0, 0, positionXYZ);
	SetShaderMaterial("screen");
	SetShaderTexture("screen");
	m_basicMeshes->DrawBoxMesh();
}
void SceneManager::DefineObjectMaterials()
{
	m_objectMaterials.clear();

	// Default: balanced
	OBJECT_MATERIAL defaultMat{};
	defaultMat.tag = "default";
	defaultMat.ambientStrength = 0.25f;
	defaultMat.ambientColor = glm::vec3(1.0f, 1.0f, 1.0f);
	defaultMat.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);
	defaultMat.specularColor = glm::vec3(0.60f, 0.60f, 0.60f);
	defaultMat.shininess = 32.0f;
	m_objectMaterials.push_back(defaultMat);

	// Screen: low specular to reduce glare/hotspots
	OBJECT_MATERIAL screenMat{};
	screenMat.tag = "screen";
	screenMat.ambientStrength = 0.18f;
	screenMat.ambientColor = glm::vec3(1.0f, 1.0f, 1.0f);
	screenMat.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);
	screenMat.specularColor = glm::vec3(0.10f, 0.10f, 0.10f);
	screenMat.shininess = 8.0f;
	m_objectMaterials.push_back(screenMat);

	// Matte black: keyboard, mouse, headphones (keeps them from looking shiny/plastic)
	OBJECT_MATERIAL matteBlack{};
	matteBlack.tag = "matteBlack";
	matteBlack.ambientStrength = 0.20f;
	matteBlack.ambientColor = glm::vec3(0.30f, 0.30f, 0.30f);
	matteBlack.diffuseColor = glm::vec3(0.35f, 0.35f, 0.35f);
	matteBlack.specularColor = glm::vec3(0.05f, 0.05f, 0.05f);
	matteBlack.shininess = 6.0f;
	m_objectMaterials.push_back(matteBlack);

	// Metal: tower/stand/frame (slightly shinier)
	OBJECT_MATERIAL metalMat{};
	metalMat.tag = "metal";
	metalMat.ambientStrength = 0.22f;
	metalMat.ambientColor = glm::vec3(0.90f, 0.90f, 0.90f);
	metalMat.diffuseColor = glm::vec3(0.90f, 0.90f, 0.90f);
	metalMat.specularColor = glm::vec3(0.75f, 0.75f, 0.75f);
	metalMat.shininess = 48.0f;
	m_objectMaterials.push_back(metalMat);
}
void SceneManager::SetupSceneLights()
{
	m_pShaderManager->setBoolValue("bUseLighting", true);

	// Light 0: overall soft white (reduce haze, better readability)
	m_pShaderManager->setVec3Value("lightSources[0].position", glm::vec3(0.0f, 7.0f, 7.0f));
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", glm::vec3(0.08f, 0.08f, 0.08f));
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", glm::vec3(0.75f, 0.75f, 0.75f));
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", glm::vec3(1.00f, 1.00f, 1.00f));

	// Light 1: orange accent near tower/fans (colored light requirement)
	m_pShaderManager->setVec3Value("lightSources[1].position", glm::vec3(5.8f, 2.3f, 1.2f));
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", glm::vec3(0.06f, 0.02f, 0.00f));
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", glm::vec3(1.00f, 0.42f, 0.05f));
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", glm::vec3(1.00f, 0.55f, 0.12f));
}